# Nginx syntax support in Atom

Adds syntax highlighting and snippet support to Nginx configuration files.
Ported from [textmate/nginx](https://github.com/johnmuhl/nginx-tmbundle) for Atom.

## How to use
Give Nginx configuration files the extension `.conf` or `.nginx`
