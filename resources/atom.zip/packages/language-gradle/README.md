#Gradle support in Atom
Adds syntax highlighting to Gradle files in Atom.

Originally [converted](http://atom.io/docs/latest/converting-a-text-mate-bundle)
from the [gradle.tmbundle](https://github.com/gradle/gradle.tmbundle).

Contributions are greatly appreciated. Please fork this repository and open a pull request to make grammar tweaks, etc.
