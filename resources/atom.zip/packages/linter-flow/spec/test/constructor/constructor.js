/* @flow */
class C {
    constructor() { }
}

class D {
    constructor():number { }
}

module.exports = C;
