This package is now **deprecated**: issues and pull requests are ignored. Thank you for your interest just the same :grin:
