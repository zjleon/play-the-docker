I have bad news and good news to share.

Bad news first: this package is now officially **deprecated.** It was always a side project that saw activity in bursts every few months as free time, life, and the day job permitted. Now, I will no longer be dedicating any more time to its upkeep, responding to pull requests or issues, or creating new releases.

The good news is that the reason this is happening is because, beginning with [Atom 1.18.0-beta0](https://atom.io/beta), there's a [much better alternative](https://github.atom.io/) built in to Atom itself! The conflict resolution tools included there should look pretty familiar :wink:

It won't really hurt anything to have both packages around, but you may want to consider uninstalling:

```
apm uninstall merge-conflicts
```
