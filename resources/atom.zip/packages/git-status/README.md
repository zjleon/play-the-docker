# atom git status

Adds git status panel to atom editor. Use ctrl-shift-s to toggle status panel.
![Screenshot](https://github.com/igorzoriy/atom-git-status/blob/master/screenshot.png?raw=true)
