## 0.7.0
* Fix [#8](https://github.com/wingyplus/language-robot-framework/issues/8) - Failed to activate the language-robot-framework package

## 0.6.0
* Add snippets Documentation and Tags
* Fix It's comment if the # is the first symbol in the cell.

## 0.5.0
* Refactor some test.

## 0.4.0
* Support "And" keyword highlight

## 0.3.0
* Add Robot Framework Selenium2Library Snippet verson 1.0.0

## 0.2.0
* Support syntax highlight for keyword "Given", "When" and "Then"

## 0.1.0 - First Release
* Add Robot Framework syntax highlight (convert from TextMate bundle)
* Auto change to Robot Framework syntax when extension file is "robot"
