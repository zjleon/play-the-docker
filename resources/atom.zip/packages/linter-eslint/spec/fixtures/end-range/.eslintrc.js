module.exports = {
  root: true,
  rules: {
    'no-unreachable': 'error'
  }
};
