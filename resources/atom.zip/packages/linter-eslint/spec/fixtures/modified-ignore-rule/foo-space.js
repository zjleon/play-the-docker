foo = 42; 
