module.exports = {
  root: true,
  rules: {
    'no-trailing-spaces': 'error'
  }
}
