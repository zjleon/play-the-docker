console.log("I'm unfixable, yay!");
foo = 42;
