/* eslint no-undef: error */

foo = 42;
