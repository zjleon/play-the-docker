foo = 42;
