var foo = 2;
