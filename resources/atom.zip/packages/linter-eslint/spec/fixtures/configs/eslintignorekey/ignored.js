var foo = 42;
