module.exports = {
  'root': true,
  'rules': {
    'semi': [2, 'never']
  }
}
