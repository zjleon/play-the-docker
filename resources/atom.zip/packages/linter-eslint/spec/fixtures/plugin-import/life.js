import { meaning } from './meaning'

console.log(`The meaning of life is ${meaning}.`)
