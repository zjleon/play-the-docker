print ('init5')
