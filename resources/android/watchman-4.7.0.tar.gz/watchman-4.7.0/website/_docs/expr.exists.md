---
id: expr.exists
title: exists
layout: docs
section: Expression Terms
permalink: docs/expr/exists.html
---

Evaluates as true if the file exists

    "exists"
    ["exists"]


