---
id: expr.true
title: "true"
layout: docs
section: Expression Terms
permalink: docs/expr/true.html
---

The `true` expression always evaluates as true.

    "true"
    ["true"]
