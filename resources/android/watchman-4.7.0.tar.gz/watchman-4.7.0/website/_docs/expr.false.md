---
id: expr.false
title: "false"
layout: docs
section: Expression Terms
permalink: docs/expr/false.html
---

The `false` expression always evaluates as false.

    "false"
    ["false"]


