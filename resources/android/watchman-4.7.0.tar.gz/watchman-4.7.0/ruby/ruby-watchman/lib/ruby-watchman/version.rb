# Copyright (c) 2014-present Facebook. All Rights Reserved.

module RubyWatchman
  VERSION = '0.0.2'
end
