# Copyright (c) 2014-present Facebook. All Rights Reserved.

$LOAD_PATH.unshift File.expand_path('../../lib', __FILE__)
$LOAD_PATH.unshift File.expand_path('../../ext', __FILE__)
require 'ruby-watchman'
