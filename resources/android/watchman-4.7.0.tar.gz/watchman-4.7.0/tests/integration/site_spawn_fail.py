#!/usr/bin/env python
# This is a simple script that fails to spawn a process in the background
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
# no unicode literals
import sys
print('failed to start')
sys.exit(1)
