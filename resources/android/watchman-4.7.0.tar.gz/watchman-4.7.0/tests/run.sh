#!/bin/bash
# This is a dumb wrapper to satisfy the buck_sh_test rule
exec "$@"
